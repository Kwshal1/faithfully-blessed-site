import Link from "next/link"
import { ChevronDown } from "lucide-react"

import { Button } from "@/components/ui/button"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import GallerySection from "@/components/gallery-section"
import AboutSection from "@/components/about-section"
import CustomOrdersSection from "@/components/custom-orders-section"
import ContactSection from "@/components/contact-section"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-[#f9f3f0] px-4 py-24 md:py-32">
          <div className="absolute inset-0 opacity-10 bg-[url('/placeholder.svg?height=600&width=800')] bg-repeat"></div>
          <div className="container relative mx-auto max-w-5xl text-center">
            <h1 className="font-serif text-4xl font-bold tracking-tight text-[#c18474] md:text-5xl lg:text-6xl">
              Faithfully Blessed Embroidery
            </h1>
            <p className="mt-4 text-xl font-medium text-[#6d5c5a]">Handcrafted Embroidery by Kimberly</p>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-[#6d5c5a]">
              From thoughtful gifts to custom keepsakes, every stitch is made with love.
            </p>
            <div className="mt-10 flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0 justify-center">
              <Button asChild className="bg-[#c18474] hover:bg-[#a87264] text-white">
                <Link href="#custom-orders">Request a Custom Order</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="border-[#c18474] text-[#c18474] hover:bg-[#f8ebe8] bg-transparent"
              >
                <Link href="#gallery">View Gallery</Link>
              </Button>
            </div>
            <div className="mt-16 animate-bounce">
              <Link href="#about" className="inline-flex items-center justify-center text-[#c18474]">
                <ChevronDown className="h-8 w-8" />
                <span className="sr-only">Scroll down</span>
              </Link>
            </div>
          </div>
        </section>

        <AboutSection />
        <GallerySection />
        <CustomOrdersSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  )
}
