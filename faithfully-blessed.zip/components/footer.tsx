import Link from "next/link"
import { Instagram, Facebook, Heart } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t bg-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="text-center md:text-left">
            <h3 className="font-serif text-lg font-medium text-[#c18474]">Faithfully Blessed Embroidery</h3>
            <p className="mt-1 text-sm text-[#6d5c5a]">Handcrafted with love in Prosper, TX</p>
          </div>

          <div className="flex items-center space-x-4">
            <Link href="https://instagram.com" className="text-[#6d5c5a] hover:text-[#c18474]">
              <Instagram className="h-5 w-5" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link href="https://facebook.com" className="text-[#6d5c5a] hover:text-[#c18474]">
              <Facebook className="h-5 w-5" />
              <span className="sr-only">Facebook</span>
            </Link>
          </div>
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-gray-200 pt-8 text-sm md:flex-row">
          <p className="text-[#6d5c5a]">
            &copy; {new Date().getFullYear()} Faithfully Blessed Embroidery. All rights reserved.
          </p>
          <p className="flex items-center text-[#6d5c5a]">
            Made with <Heart className="mx-1 h-4 w-4 text-[#c18474]" /> in Prosper, Texas
          </p>
        </div>
      </div>
    </footer>
  )
}
