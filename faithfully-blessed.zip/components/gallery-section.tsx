import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Instagram } from "lucide-react"

const galleryItems = [
  {
    id: 1,
    title: "Custom Baby Onesie",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 2,
    title: "Floral Hoop Art",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 3,
    title: "Home Decor Pillow",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 4,
    title: "Wedding Gift",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 5,
    title: "Monogrammed Towel",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 6,
    title: "Seasonal Decoration",
    image: "/placeholder.svg?height=400&width=400",
  },
]

export default function GallerySection() {
  return (
    <section id="gallery" className="bg-[#f9f3f0] py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-5xl">
          <h2 className="font-serif text-3xl font-bold text-center text-[#c18474] md:text-4xl">Gallery</h2>
          <p className="mt-4 text-center text-lg text-[#6d5c5a]">
            Browse through some of my favorite embroidery creations
          </p>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 md:grid-cols-3">
            {galleryItems.map((item) => (
              <div
                key={item.id}
                className="group relative overflow-hidden rounded-lg bg-white shadow-md transition-all hover:shadow-lg"
              >
                <div className="relative h-64 w-full overflow-hidden">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.title}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium text-[#6d5c5a]">{item.title}</h3>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Button className="bg-[#c18474] hover:bg-[#a87264] text-white inline-flex items-center gap-2">
              <Instagram className="h-4 w-4" />
              <span>View More on Instagram</span>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
