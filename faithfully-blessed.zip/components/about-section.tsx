import Image from "next/image"

export default function AboutSection() {
  return (
    <section id="about" className="bg-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-5xl">
          <h2 className="font-serif text-3xl font-bold text-center text-[#c18474] md:text-4xl">Meet Kimberly</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-2 items-center">
            <div className="relative h-64 overflow-hidden rounded-lg md:h-80 lg:h-96">
              <Image
                src="/placeholder.svg?height=600&width=400"
                alt="Kimberly at her embroidery workspace"
                fill
                className="object-cover"
              />
            </div>
            <div className="space-y-4">
              <p className="text-lg text-[#6d5c5a]">
                Hi! I&apos;m Kimberly, and embroidery started as a fun hobby that turned into a passion—and eventually,
                my small business. Every item I sell is stitched by me, whether it&apos;s a ready-made item in my
                boutique space or a custom request from a customer. I believe in slow-made, thoughtful gifts that bring
                joy.
              </p>
              <p className="text-lg text-[#6d5c5a]">
                You can find my boutique space inside The Painted Tree in Prosper, TX, where I showcase a selection of
                my handcrafted embroidery pieces. While I don&apos;t offer on-site embroidery at the store, I welcome
                custom orders that I fulfill from my personal studio.
              </p>
              <p className="text-lg text-[#6d5c5a]">
                Each piece is created with care, attention to detail, and a prayer of blessing for the person who will
                receive it.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
