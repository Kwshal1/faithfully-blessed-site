"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, MapPin, Instagram, Facebook } from "lucide-react"

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Form submission logic would go here
    console.log("Form submitted:", formData)
    // Reset form
    setFormData({ name: "", email: "", message: "" })
    alert("Thank you for your message! I'll get back to you soon.")
  }

  return (
    <section id="contact" className="bg-[#f9f3f0] py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-5xl">
          <h2 className="font-serif text-3xl font-bold text-center text-[#c18474] md:text-4xl">Contact Me</h2>
          <p className="mt-4 text-center text-lg text-[#6d5c5a]">
            Have questions or want to place an order? I&apos;d love to hear from you!
          </p>

          <div className="mt-12 grid gap-8 md:grid-cols-2">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <Mail className="h-6 w-6 text-[#c18474]" />
                <div>
                  <h3 className="font-medium text-[#6d5c5a]">Email</h3>
                  <p className="mt-1 text-[#6d5c5a]">faithfullyblessed@email.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <MapPin className="h-6 w-6 text-[#c18474]" />
                <div>
                  <h3 className="font-medium text-[#6d5c5a]">Location</h3>
                  <p className="mt-1 text-[#6d5c5a]">Boutique space inside The Painted Tree, Prosper, TX</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Instagram className="h-6 w-6 text-[#c18474]" />
                <div>
                  <h3 className="font-medium text-[#6d5c5a]">Instagram</h3>
                  <p className="mt-1 text-[#6d5c5a]">@faithfullyblessedembroidery</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Facebook className="h-6 w-6 text-[#c18474]" />
                <div>
                  <h3 className="font-medium text-[#6d5c5a]">Facebook</h3>
                  <p className="mt-1 text-[#6d5c5a]">@faithfullyblessedembroidery</p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 rounded-lg bg-white p-6 shadow-md">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-[#6d5c5a]">
                  Name
                </label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="mt-1 border-[#e5d6d0] focus:border-[#c18474] focus:ring-[#c18474]"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-[#6d5c5a]">
                  Email
                </label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="mt-1 border-[#e5d6d0] focus:border-[#c18474] focus:ring-[#c18474]"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-[#6d5c5a]">
                  Message
                </label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  className="mt-1 min-h-[120px] border-[#e5d6d0] focus:border-[#c18474] focus:ring-[#c18474]"
                />
              </div>

              <Button type="submit" className="w-full bg-[#c18474] hover:bg-[#a87264] text-white">
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
