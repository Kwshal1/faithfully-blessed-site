import { Button } from "@/components/ui/button"
import Link from "next/link"
import { CheckCircle } from "lucide-react"

const customOptions = [
  "Baby gifts (onesies, bibs)",
  "Home decor (pillows, wall hoops)",
  "Wedding or seasonal embroidery",
  "Monogrammed items",
]

export default function CustomOrdersSection() {
  return (
    <section id="custom-orders" className="bg-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-serif text-3xl font-bold text-[#c18474] md:text-4xl">Create Something Special</h2>
          <p className="mt-6 text-lg text-[#6d5c5a]">
            Looking for a personalized embroidered gift? I&apos;d love to work with you! Whether it&apos;s a name,
            phrase, theme, or design idea, send me your vision and I&apos;ll stitch it with care.
          </p>
          <div className="mt-8 space-y-4">
            <h3 className="text-xl font-medium text-[#6d5c5a]">I accept custom orders for:</h3>
            <ul className="mt-4 space-y-3">
              {customOptions.map((option, index) => (
                <li key={index} className="flex items-center justify-center gap-2">
                  <CheckCircle className="h-5 w-5 text-[#c18474]" />
                  <span className="text-[#6d5c5a]">{option}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="mt-10">
            <Button asChild className="bg-[#c18474] hover:bg-[#a87264] text-white">
              <Link href="#contact">Start a Custom Order</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
