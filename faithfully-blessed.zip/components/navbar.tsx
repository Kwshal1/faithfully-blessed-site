"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center">
          <span className="font-serif text-xl font-bold text-[#c18474]">Faithfully Blessed</span>
        </Link>
        <nav className="hidden md:flex md:items-center md:space-x-8">
          <Link href="/" className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]">
            Home
          </Link>
          <Link href="#about" className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]">
            About
          </Link>
          <Link href="#gallery" className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]">
            Gallery
          </Link>
          <Link href="#custom-orders" className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]">
            Custom Orders
          </Link>
          <Link href="#contact" className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]">
            Contact
          </Link>
        </nav>
        <button className="md:hidden" onClick={toggleMenu}>
          {isMenuOpen ? <X className="h-6 w-6 text-[#6d5c5a]" /> : <Menu className="h-6 w-6 text-[#6d5c5a]" />}
        </button>
      </div>
      {isMenuOpen && (
        <div className="container mx-auto px-4 pb-4 md:hidden">
          <nav className="flex flex-col space-y-4">
            <Link
              href="/"
              className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="#about"
              className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
            <Link
              href="#gallery"
              className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]"
              onClick={() => setIsMenuOpen(false)}
            >
              Gallery
            </Link>
            <Link
              href="#custom-orders"
              className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]"
              onClick={() => setIsMenuOpen(false)}
            >
              Custom Orders
            </Link>
            <Link
              href="#contact"
              className="text-sm font-medium text-[#6d5c5a] hover:text-[#c18474]"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
